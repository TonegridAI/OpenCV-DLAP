#ifndef DLIB_REVISION_H
// Version:  19.7
// Date:     Sun Sep 17 08:28:31 EDT 2017
// Mercurial Revision ID:  85172ddad00b
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  7
#define DLIB_PATCH_VERSION  0
#endif
